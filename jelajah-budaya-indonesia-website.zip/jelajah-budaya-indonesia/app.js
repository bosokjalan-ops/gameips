const QUESTIONS = [
{c:"Rumah Adat",q:"Rumah Gadang berasal dari daerah mana?",o:["Sumatera Barat","Jawa Barat","Bali","Papua"],a:0,e:"Rumah Gadang merupakan rumah adat Minangkabau dari Sumatera Barat."},
{c:"Tarian",q:"Tari Saman berasal dari provinsi mana?",o:["Bali","Aceh","Jawa Tengah","Papua"],a:1,e:"Tari Saman berasal dari Aceh dan terkenal dengan gerakan tangan yang kompak."},
{c:"Alat Musik",q:"Alat musik angklung berasal dari daerah mana?",o:["Jawa Barat","Maluku","Kalimantan","Sulawesi"],a:0,e:"Angklung adalah alat musik tradisional dari Jawa Barat yang dimainkan dengan cara digoyangkan."},
{c:"Rumah Adat",q:"Apa nama rumah adat tradisional dari wilayah pegunungan Papua?",o:["Joglo","Honai","Gadang","Tongkonan"],a:1,e:"Honai merupakan rumah tradisional masyarakat Papua, khususnya wilayah pegunungan."},
{c:"Tarian",q:"Tari Kecak berasal dari daerah mana?",o:["Aceh","Bali","Sumatera Utara","Jawa Timur"],a:1,e:"Tari Kecak berasal dari Bali dan terkenal dengan paduan suara penarinya."},
{c:"Makanan",q:"Rendang merupakan makanan khas dari daerah mana?",o:["Sumatera Barat","Jawa Barat","Papua","Banten"],a:0,e:"Rendang adalah makanan khas Minangkabau, Sumatera Barat."},
{c:"Rumah Adat",q:"Rumah Tongkonan merupakan rumah adat masyarakat mana?",o:["Dayak","Toraja","Baduy","Minangkabau"],a:1,e:"Tongkonan adalah rumah adat masyarakat Toraja di Sulawesi Selatan."},
{c:"Alat Musik",q:"Alat musik Sasando berasal dari mana?",o:["Nusa Tenggara Timur","Jawa Tengah","Aceh","Bali"],a:0,e:"Sasando berasal dari Pulau Rote, Nusa Tenggara Timur."},
{c:"Pakaian Adat",q:"Batik dibuat dengan teknik yang menggunakan bahan perintang berupa apa?",o:["Lem kertas","Lilin malam","Pasir","Tanah liat"],a:1,e:"Batik dibuat dengan menggunakan lilin malam untuk membentuk motif pada kain."},
{c:"Tarian",q:"Tari Piring berasal dari daerah mana?",o:["Sumatera Barat","Jawa Barat","Maluku","Kalimantan Timur"],a:0,e:"Tari Piring berasal dari Minangkabau, Sumatera Barat."},
{c:"Pakaian Adat",q:"Ulos merupakan kain tradisional yang erat dengan budaya masyarakat mana?",o:["Batak","Dayak","Asmat","Betawi"],a:0,e:"Ulos merupakan kain tradisional yang penting dalam adat masyarakat Batak di Sumatera Utara."},
{c:"Suku Bangsa",q:"Suku Dayak banyak dikenal berasal dari pulau mana?",o:["Jawa","Kalimantan","Bali","Sulawesi"],a:1,e:"Masyarakat Dayak merupakan kelompok masyarakat adat yang berasal dari Pulau Kalimantan."},
{c:"Alat Musik",q:"Kolintang adalah alat musik tradisional dari daerah mana?",o:["Sulawesi Utara","Papua","Aceh","Bali"],a:0,e:"Kolintang berasal dari Minahasa, Sulawesi Utara."},
{c:"Budaya",q:"Keris dikenal sebagai senjata tradisional yang berkembang kuat dalam budaya daerah mana?",o:["Jawa","Papua","Maluku","NTT"],a:0,e:"Keris memiliki sejarah panjang dan nilai budaya di berbagai daerah, terutama Jawa."},
{c:"Budaya",q:"Mengapa kita harus menghargai keragaman budaya Indonesia?",o:["Agar budaya lain hilang","Agar semua daerah sama","Untuk menjaga persatuan dan melestarikan budaya","Agar hanya budaya sendiri yang dikenal"],a:2,e:"Menghargai perbedaan budaya membantu menjaga persatuan dan melestarikan warisan bangsa."}
];
const CULTURE = [
["🏠","Rumah Gadang","Sumatera Barat","Rumah adat Minangkabau dengan atap berbentuk seperti tanduk kerbau."],
["🛖","Honai","Papua","Rumah tradisional berbentuk bulat dengan atap menyerupai kubah."],
["💃","Tari Saman","Aceh","Tarian kelompok yang mengutamakan kekompakan gerakan dan nyanyian."],
["🎵","Angklung","Jawa Barat","Alat musik bambu yang dimainkan dengan cara digoyangkan."],
["🎶","Sasando","Nusa Tenggara Timur","Alat musik petik tradisional yang berasal dari Pulau Rote."],
["🍛","Rendang","Sumatera Barat","Masakan daging berbumbu rempah yang dimasak dalam waktu lama."],
["🏡","Tongkonan","Sulawesi Selatan","Rumah adat masyarakat Toraja dengan atap melengkung khas."],
["🥁","Kolintang","Sulawesi Utara","Alat musik pukul dari kayu yang berasal dari Minahasa."]
];
const $ = id => document.getElementById(id);
let db = null, currentQuestions = [], currentIndex = 0, selected = false;
let player = "", classId = "kelas5", score = 0, correct = 0, streak = 0, resultData = null;

function showPage(id){
  document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id===id));
  document.querySelectorAll(".nav-btn").forEach(b=>b.classList.toggle("active",b.dataset.page===id));
  if(id==="leaderboard") loadLeaderboard();
  window.scrollTo({top:0,behavior:"smooth"});
}
document.querySelectorAll("[data-page]").forEach(b=>b.addEventListener("click",()=>showPage(b.dataset.page)));
$("start-btn").onclick=()=>showPage("play");
$("begin-quiz").onclick=startQuiz;
$("next-question").onclick=nextQuestion;
$("see-rank").onclick=()=>showPage("leaderboard");
$("play-again").onclick=()=>showPage("play");
$("refresh-board").onclick=loadLeaderboard;

function initFirebase(){
  try{
    const cfg=window.FIREBASE_CONFIG;
    if(!cfg || !cfg.apiKey || cfg.apiKey.startsWith("GANTI_")) return false;
    firebase.initializeApp(cfg);
    db=firebase.firestore();
    return true;
  }catch(e){console.error(e);return false;}
}
const firebaseReady=initFirebase();

function startQuiz(){
  const name=$("player-name").value.trim();
  if(name.length<2){$("setup-error").textContent="Masukkan nama minimal 2 karakter.";return;}
  player=name;
  classId=($("class-code").value.trim().toLowerCase().replace(/[^a-z0-9_-]/g,"").slice(0,20)||"kelas5");
  const count=Number($("question-count").value);
  currentQuestions=[...QUESTIONS].sort(()=>Math.random()-.5).slice(0,count);
  currentIndex=0;score=0;correct=0;streak=0;
  $("setup-panel").classList.add("hidden");$("quiz-panel").classList.remove("hidden");
  $("setup-error").textContent="";
  renderQuestion();showPage("play");
}
function renderQuestion(){
  selected=false;
  const q=currentQuestions[currentIndex];
  $("question-counter").textContent=`SOAL ${currentIndex+1} / ${currentQuestions.length}`;
  $("live-score").textContent=`⭐ ${score} poin`;
  $("progress-fill").style.width=`${(currentIndex/currentQuestions.length)*100}%`;
  $("question-category").textContent=q.c.toUpperCase();
  $("question-text").textContent=q.q;
  $("feedback").className="feedback hidden";$("next-question").classList.add("hidden");
  const list=$("answer-list");list.innerHTML="";
  q.o.forEach((option,i)=>{
    const btn=document.createElement("button");btn.className="answer-btn";
    const letter=document.createElement("span");letter.className="answer-letter";letter.textContent=String.fromCharCode(65+i);
    const text=document.createElement("span");text.textContent=option;
    btn.append(letter,text);btn.onclick=()=>chooseAnswer(i,btn);list.append(btn);
  });
}
function chooseAnswer(choice,clicked){
  if(selected)return;selected=true;
  const q=currentQuestions[currentIndex],right=choice===q.a;
  [...$("answer-list").children].forEach((b,i)=>{b.disabled=true;if(i===q.a)b.classList.add("correct");else if(i===choice)b.classList.add("wrong");});
  if(right){score+=100+Math.min(streak,5)*10;correct++;streak++;}else streak=0;
  $("live-score").textContent=`⭐ ${score} poin`;
  $("feedback").className=`feedback ${right?"":"bad"}`;
  $("feedback").textContent=(right?"🎉 Hebat! Jawabanmu benar. ":"💡 Belum tepat. ")+q.e;
  $("next-question").classList.remove("hidden");
  $("next-question").textContent=currentIndex===currentQuestions.length-1?"Lihat hasil →":"Soal berikutnya →";
}
function nextQuestion(){
  currentIndex++;
  if(currentIndex<currentQuestions.length)renderQuestion();else finishQuiz();
}
async function finishQuiz(){
  const total=currentQuestions.length,accuracy=Math.round(correct/total*100);
  const award=accuracy>=90?"🏆 Maestro Budaya":accuracy>=70?"🌟 Duta Budaya":accuracy>=50?"🧭 Penjelajah Budaya":"🌱 Pemula Budaya";
  resultData={name:player,score,correct,total,accuracy,award,createdAt:firebase.firestore?firebase.firestore.FieldValue.serverTimestamp():new Date()};
  $("result-title").textContent=`Hebat, ${player}!`;
  $("final-score").textContent=score;$("correct-count").textContent=correct;
  $("wrong-count").textContent=total-correct;$("accuracy").textContent=accuracy+"%";
  $("award-label").textContent=award;
  $("save-status").textContent="Menyimpan hasil ke papan peringkat…";
  $("setup-panel").classList.remove("hidden");$("quiz-panel").classList.add("hidden");
  showPage("result");
  await saveResult();
}
async function saveResult(){
  if(!db){$("save-status").textContent="Mode demo: Firebase belum dihubungkan. Hasil belum masuk ke papan peringkat bersama.";return;}
  try{
    const payload={name:resultData.name,score:resultData.score,correct:resultData.correct,total:resultData.total,accuracy:resultData.accuracy,award:resultData.award,createdAt:firebase.firestore.FieldValue.serverTimestamp()};
    await db.collection("classrooms").doc(classId).collection("scores").add(payload);
    $("save-status").textContent="✅ Hasil berhasil disimpan ke papan peringkat kelas!";
  }catch(e){console.error(e);$("save-status").textContent="Hasil belum tersimpan. Periksa koneksi atau pengaturan Firebase."; }
}
async function loadLeaderboard(){
  const target=$("leaderboard-list"),message=$("board-message");
  target.innerHTML='<div class="loading">Memuat peringkat…</div>';
  if(!db){target.innerHTML='<div class="loading">Papan peringkat online akan aktif setelah Firebase dikonfigurasi.</div>';message.textContent="Situs dapat dicoba dalam mode demo, tetapi belum menerima skor bersama.";return;}
  try{
    const snap=await db.collection("classrooms").doc(classId).collection("scores").orderBy("score","desc").limit(35).get();
    if(snap.empty){target.innerHTML='<div class="loading">Belum ada skor. Jadilah penjelajah pertama!</div>';message.textContent="";return;}
    const rows=snap.docs.map(d=>d.data());
    target.innerHTML="";
    rows.forEach((r,i)=>{
      const row=document.createElement("div");row.className="rank-row";
      const no=document.createElement("span");no.className="rank-no";no.textContent=i+1;
      const medal=document.createElement("span");medal.className="rank-medal";medal.textContent=["🥇","🥈","🥉"][i]||"🌟";
      const name=document.createElement("span");name.className="rank-name";name.textContent=r.name;
      const sub=document.createElement("small");sub.textContent=`${r.correct}/${r.total} jawaban benar`;name.append(sub);
      const points=document.createElement("span");points.className="rank-score";points.textContent=`${r.score} poin`;
      row.append(no,medal,name,points);target.append(row);
    });
    message.textContent=`Menampilkan ${rows.length} hasil teratas.`;
  }catch(e){console.error(e);target.innerHTML='<div class="loading">Tidak dapat memuat peringkat. Periksa konfigurasi dan Firestore Rules.</div>';}
}
function renderLearn(){
  const grid=$("learn-grid");
  CULTURE.forEach(item=>{
    const card=document.createElement("article");card.className="learn-card";
    const emoji=document.createElement("div");emoji.className="emoji";emoji.textContent=item[0];
    const title=document.createElement("h3");title.textContent=item[1];
    const region=document.createElement("div");region.className="region";region.textContent=item[2];
    const desc=document.createElement("p");desc.textContent=item[3];
    card.append(emoji,title,region,desc);grid.append(card);
  });
}
renderLearn();
if(!firebaseReady)console.info("Firebase belum dikonfigurasi. Jalankan dengan mode demo atau ikuti README.");
