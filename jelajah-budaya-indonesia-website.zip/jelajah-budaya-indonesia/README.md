# Jelajah Budaya Indonesia — Website Kuis IPS Kelas 5

Website kuis budaya Indonesia yang responsif untuk HP dan laptop. Mendukung nama pemain, 10/15 soal, feedback jawaban, skor, penghargaan, ensiklopedia budaya, dan leaderboard online 35 hasil teratas per kelas.

## Isi paket
- `index.html` — halaman website
- `style.css` — tampilan responsif
- `app.js` — alur kuis dan leaderboard
- `firebase-config.example.js` — contoh konfigurasi Firebase
- `firestore.rules` — aturan awal Firestore

## A. Menyiapkan Firebase (gratis sesuai kuota paket Spark)
1. Buka https://console.firebase.google.com/ dan buat project.
2. Tambahkan aplikasi Web (ikon `</>`).
3. Salin konfigurasi Firebase yang diberikan.
4. Di folder website, salin `firebase-config.example.js` menjadi `firebase-config.js`.
5. Isi nilai `apiKey`, `authDomain`, `projectId`, `storageBucket`, `messagingSenderId`, dan `appId` sesuai konfigurasi project milikmu.
6. Di menu **Build → Firestore Database**, buat database. Pilih lokasi yang dekat, misalnya `asia-southeast2` jika tersedia.
7. Buka tab **Rules**, ganti aturan dengan isi file `firestore.rules`, lalu klik **Publish**.

> Catatan: konfigurasi Firebase Web memang berada di sisi browser. Keamanan database harus ditentukan oleh Firestore Rules. Aturan contoh ini membatasi bentuk data dan skor, tetapi aplikasi publik tanpa login/backend tepercaya tidak dapat membuktikan bahwa skor benar-benar diperoleh secara jujur. Untuk kompetisi resmi, gunakan Firebase Authentication anonim + App Check dan validasi skor melalui Cloud Functions/backend.

## B. Menjalankan website
Bisa dites lokal dengan ekstensi Live Server di VS Code, atau unggah isi folder ke layanan hosting statis.

## C. Publikasi ke internet dengan Netlify
1. Buka https://app.netlify.com/drop
2. Pastikan file `firebase-config.js` sudah dibuat dan diisi.
3. Seret folder website (atau folder hasil ekstrak ZIP) ke area upload Netlify Drop.
4. Netlify akan memberikan alamat publik `https://....netlify.app`.
5. Bagikan link tersebut kepada siswa.

Alternatif: gunakan Vercel (https://vercel.com/) atau Firebase Hosting.

## D. Mengatur kelas
- Siswa memasukkan kode kelas yang sama, misalnya `KELAS5A`.
- Semua siswa dengan kode yang sama melihat papan peringkat yang sama.
- Leaderboard menampilkan maksimal 35 hasil skor tertinggi.
- Untuk menjaga privasi, gunakan nama depan + inisial bila guru menghendaki.

## Penting
Paket ini adalah source website yang siap dikonfigurasi, bukan website yang sudah dipublikasikan. Saya tidak dapat membuat project Firebase atau akun hosting atas nama pengguna. Setelah konfigurasi Firebase dan hosting dilakukan, link publik dapat dibagikan.
