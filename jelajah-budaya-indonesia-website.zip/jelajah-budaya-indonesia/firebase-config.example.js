// 1) Buat project di https://console.firebase.google.com/
// 2) Tambahkan aplikasi Web, lalu salin konfigurasi Firebase ke file firebase-config.js
// 3) Aktifkan Firestore Database.
window.FIREBASE_CONFIG = {
  apiKey: "GANTI_DENGAN_API_KEY",
  authDomain: "GANTI_DENGAN_PROJECT.firebaseapp.com",
  projectId: "GANTI_DENGAN_PROJECT_ID",
  storageBucket: "GANTI_DENGAN_PROJECT.appspot.com",
  messagingSenderId: "GANTI_DENGAN_SENDER_ID",
  appId: "GANTI_DENGAN_APP_ID"
};